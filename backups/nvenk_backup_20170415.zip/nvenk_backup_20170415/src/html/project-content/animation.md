<!-- ## The Story

Before my foray into the world of user experience, I worked as a character animator. I met some really awesome people and got to work on some projects that were even more so.

I worked on a lot of television shows, including the daytime emmy award nominated shows: Dragons - Riders of Berk, and Teenage Mutant Ninja Turtles. I had the opportunity to animate some iconic characters like Hiccup from 'How to Train Your Dragon', Puss from 'Puss in Boots', and the Ninja Turtles. I could talk about this forever, but showing is better than telling.

So without further ado... -->

## 2014 Character Animation Showreel

<div class="videoWrapper">
    <iframe src="https://player.vimeo.com/video/94683657" width="500" height="281" webkitallowfullscreen mozallowfullscreen allowfullscreen>
    </iframe>
</div>
&nbsp;

*This reel is from 2014. A lot of content over mid 2014 - early 2016 are under NDA and cannot be shown publicly yet.*
